from django.urls import path
from . import views

app_name = 'biblidoaluno'

urlpatterns = [
    path('', views.home_view, name='home'),
    path('inicio/', views.inicio, name='inicio'),
    path('livros/', views.listar_livros, name='listar_livros'),
    path('livros/<int:pk>/', views.detalhe_livro, name='detalhe_livro'),
    path('livros/categoria/<str:nome_categoria>/', views.listar_por_categoria, name='listar_por_categoria'),
]
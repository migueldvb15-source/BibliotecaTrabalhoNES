from django.shortcuts import render, get_object_or_404
from .models import Livro

def home_view(request):
    livros = Livro.objects.all()
    return render(request, "biblidoaluno/home.html", {"livros": livros})

def inicio(request):
    contexto = {
        "nome_projeto": "BiblioFácil - Gestão de Empréstimos",
        "descricao": "Sistema para controle e acompanhamento de retirada e devolução de livros da biblioteca escolar."
    }
    return render(request, "biblidoaluno/inicio.html", contexto)

def listar_livros(request):
    livros = Livro.objects.all()
    return render(request, "biblidoaluno/listar_livros.html", {"livros": livros})

def detalhe_livro(request, pk):
    livro = get_object_or_404(Livro, pk=pk)
    return render(request, 'biblidoaluno/detalhe.html', {'livro': livro})

def listar_por_categoria(request, nome_categoria):
    livros_filtrados = Livro.objects.filter(categoria__iexact=nome_categoria)
    contexto = {
        'nome_categoria': nome_categoria,
        'livros': livros_filtrados
    }
    return render(request, 'biblidoaluno/lista_categoria.html', contexto)
from django.shortcuts import render
from .models import Livro

def inicio(request):
    contexto = {
        "nome_projeto": "BiblioFácil - Gestão de Empréstimos",
        "descricao": "Sistema para controle e acompanhamento de retirada e devolução de livros da biblioteca escolar."
    }
    return render(request, "biblidoaluno/inicio.html", contexto)

def listar_livros(request):
    livros = Livro.objects.all()
    contexto = {'livros': livros}
    return render(request, "biblidoaluno/listar_livros.html", contexto)


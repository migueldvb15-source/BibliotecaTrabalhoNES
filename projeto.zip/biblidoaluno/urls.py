from django.urls import path
from . import views

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('livros/', views.listar_livros, name='listar_livros'),
]